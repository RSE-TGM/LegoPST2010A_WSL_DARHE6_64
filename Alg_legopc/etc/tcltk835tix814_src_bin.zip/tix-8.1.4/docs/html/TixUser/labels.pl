# LaTeX2HTML 0.5.3 (Wed Jan 26 1994)
# Associate symbolic labels with physical files.

$external_labels{"Introduction"} ="$URL/section3_2.html"; 
$external_labels{"TixObjectOrientedProgramming"} ="$URL/subsectionstar3_6_1.html"; 
$external_labels{"Installing"} ="$URL/subsection3_2_2.html"; 
$external_labels{"TableofContents"} ="$URL/tableofcontents3_1.html"; 
$external_labels{"TixClassStructure"} ="$URL/sectionstar3_7.html"; 
$external_labels{"TixWidgets"} ="$URL/subsubsection3_3_1_8.html"; 
$external_labels{"TixCommands"} ="$URL/subsection3_3_2.html"; 
$external_labels{"TixWidgetSet"} ="$URL/section3_3.html"; 

1;