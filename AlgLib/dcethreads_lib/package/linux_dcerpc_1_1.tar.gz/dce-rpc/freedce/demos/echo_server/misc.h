void  chk_dce_err(error_status_t, char *, char *, unsigned int);
