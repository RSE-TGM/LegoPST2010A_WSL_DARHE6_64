/*
 * echo_server      : demo DCE RPC application
 *
 * Jim Doyle, jrd@bu.edu  09-05-1998
 *
 *
 */


/**************************************************************************
 * Port to Linux IA32 / Alpha / x86_64 with gcc 3.x 
 **************************************************************************
 *
 * Contact Information: Loic Domaigne <loicWorks@gmx.net> 
 * -------------------
 *
 * Change Log
 * ----------
 *
 * Loic- 2003.05.05
 *  include <stdlib.h> to fix the warning "implicit declaration of 
 *  function 'exit'"
 *
 * Loic- 2003.05.08 
 *  Fixed portability issue on Alpha (the for index i in ReverseIt() is a 
 *  unsigned int on Alpha)
 *
 * Loic- 2004.12.10
 *  Port to general LP64 architecture (including among others x86_64)
 *
 **************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <dce/rpc.h>
#include <dce/pthread_exc.h>
#include "echo.h"
#include "misc.h"

pthread_t sig_handler_thread;
static void signal_handler(void * arg);
static void wait_for_signals();

/*
 *
 * A template DCE RPC server
 *
 * main() contains the basic calls needed to register an interface,
 * get communications endpoints, and register the endpoints
 * with the endpoint mapper.
 *
 * ReverseIt() implements the interface specified in echo.idl
 *
 */


int main(int ac __attribute__((__unused__)), char *av[] __attribute__((__unused__)))
{
  unsigned32 status;
  rpc_binding_vector_p_t     server_binding;
  char * string_binding;
  unsigned32 i;

  /*
   * Register the Interface with the local endpoint mapper (rpcd)
   */

  printf ("Registering server.... \n");
  rpc_server_register_if(echo_v1_0_s_ifspec, 
			 NULL,
			 NULL,
			 &status);
      chk_dce_err(status, "rpc_server_register_if()", "", 1);

	printf("registered.\nPreparing binding handle...\n");
  
      /*
       * Prepare the server binding handle
       * use all avail protocols (UDP and TCP). This basically allocates
       * new sockets for us and associates the interface UUID and
       * object UUID of with those communications endpoints.
       */

  rpc_server_use_all_protseqs(rpc_c_protseq_max_calls_default, &status);
      chk_dce_err(status, "rpc_server_use_all_protseqs()", "", 1);
  rpc_server_inq_bindings(&server_binding, &status);
      chk_dce_err(status, "rpc_server_inq_bindings()", "", 1);

      /*
       * Register bindings with the endpoint mapper
       */

	printf("registering bindings with endpoint mapper\n");
		
  rpc_ep_register(echo_v1_0_s_ifspec,
		  server_binding,
		  NULL,
		  (unsigned char *)"QDA application server",
		  &status);
      chk_dce_err(status, "rpc_ep_register()", "", 1);

	printf("registered.\n");

      /*
       * Print out the servers endpoints (TCP and UDP port numbers)
       */

  printf ("Server's communications endpoints are:\n");
 
  for (i=0; i<server_binding->count; i++)
    {
      rpc_binding_to_string_binding(server_binding->binding_h[i], 
				    (unsigned char **)&string_binding,
				    &status
				    );
      if (string_binding)
		printf("\t%s\n",string_binding);
    }


  /*
   * Start the signal waiting thread in background. This thread will
   * Catch SIGINT and gracefully shutdown the server.
   */

  wait_for_signals();

  /*
   * Begin listening for calls
   */

  printf ("listening for calls.... \n");

  TRY
    {
      rpc_server_listen(rpc_c_listen_max_calls_default, &status);
    }
  CATCH_ALL
    {
      printf ("Server stoppped listening\n");
    }
  ENDTRY

    /*
     * If we reached this point, then the server was stopped, most likely
     * by the signal handler thread called rpc_mgmt_stop_server().
     * gracefully cleanup and unregister the bindings from the 
     * endpoint mapper. 
     */

    /*
     * Kill the signal handling thread
     */

  printf("Killing the signal handler thread... \n");
  pthread_cancel(sig_handler_thread);

  printf ("Unregistering server from the endpoint mapper.... \n");
  rpc_ep_unregister(echo_v1_0_s_ifspec,
		    server_binding,
		    NULL,
		    &status);
  chk_dce_err(status, "rpc_ep_unregister()", "", 0);

  /*
   * retire the binding information
   */

  printf("Cleaning up communications endpoints... \n");
  rpc_server_unregister_if(echo_v1_0_s_ifspec,
			   NULL,
			   &status);
  chk_dce_err(status, "rpc_server_unregister_if()", "", 0);

  exit(0);

}


/*=========================================================================
 *
 * Server implementation of ReverseIt()
 *
 *=========================================================================*/

idl_boolean 
ReverseIt(h, in_text, out_text, status)
     rpc_binding_handle_t h;
     args * in_text;
     args ** out_text;
     error_status_t * status;
{

  char * binding_info;
  error_status_t e;
  unsigned result_size;
  args * result;
  unsigned32 i,j,l;

  /*
   * Get some info about the client binding
   */

  rpc_binding_to_string_binding(h, (unsigned char **)&binding_info, &e);
  if (e == rpc_s_ok)
    {
      printf ("ReverseIt() called by client: %s\n", binding_info);
    }

  if (in_text == NULL) return 0;

  /*
   *  Print the in_text
   */

  printf("\n\nFunction ReverseIt() -- input argments\n");
  
  for (i=0; i<in_text->argc; i++)
    /* make sure we print things right on LP64 */
#if defined(__LP64)
    	printf("\t[arg %u]: %s\n", i, in_text->argv[i]);
#else
	printf("\t[arg %lu]: %s\n", i, in_text->argv[i]);
#endif
  printf ("\n=========================================\n");
  
  /*
   * Allocate the output args as dynamic storage bound
   * to this RPC. The output args are the same size as the
   * input args since we are simply reversing strings.
   */

  result_size = sizeof(args) + in_text->argc * sizeof(string_t *);
  result = (args * )rpc_ss_allocate(result_size);
  result->argc = in_text->argc;
  
  for (i=0; i < in_text->argc; i++)
    {
      result->argv[i] = 
	(string_t)rpc_ss_allocate(strlen(in_text->argv[i]) + 1);
    }

  /* 
   * do the string reversal
   */

  for (i=0; i < in_text->argc; i++)
    {
      l = strlen(in_text->argv[i]);
      for (j=0; j<l; j++)
	{
	  result->argv[i][j] = in_text->argv[i][l-j-1];
	}
      result->argv[i][l]=0;           /* make sure its null terminated! */
    }

  *out_text = result;
  *status = error_status_ok;

  return 1;

}


/*=========================================================================
 *
 * wait_for_signals()
 *
 *
 * Set up the process environment to properly deal with signals.
 * By default, we isolate all threads from receiving asynchronous
 * signals. We create a thread that handles all async signals. 
 * The signal handling actions are handled in the handler thread.
 *
 * For AIX, we cant use a thread that sigwaits() on a specific signal,
 * we use a plain old, lame old Unix signal handler.
 *
 *=========================================================================*/

void 
wait_for_signals()
{

sigset_t default_signal_mask;
sigset_t old_signal_mask;

#if defined(__linux__)
  sigemptyset(&default_signal_mask);
  pthread_sigmask(SIG_BLOCK,  &default_signal_mask, &old_signal_mask);
#endif

#ifndef _AIX
  pthread_create(&sig_handler_thread, 
		 pthread_attr_default,
		 (void*)signal_handler,
		 NULL);
#endif

#ifdef _AIX
  signal(SIGINT, (void (*)(int))signal_handler);
#endif

}



static void
signal_handler(void * arg __attribute__((__unused__)))
{

  sigset_t catch_signal_mask;
  sigset_t old_signal_mask;
  int which_signal;
  unsigned32 status;

#if defined(__linux__)
  sigemptyset(&catch_signal_mask);
  sigaddset(&catch_signal_mask, SIGINT);

  pthread_sigmask(SIG_BLOCK,  &catch_signal_mask, &old_signal_mask);
#endif

  while (1) 
    {
      
#ifndef _AIX
      /* Wait for a signal to arrive */
      sigwait(&catch_signal_mask, &which_signal);

      if ((which_signal == SIGINT) || (which_signal == SIGQUIT))
	rpc_mgmt_stop_server_listening(NULL, &status);
#endif

#ifdef _AIX
	rpc_mgmt_stop_server_listening(NULL, &status);
#endif

    }
  
}









